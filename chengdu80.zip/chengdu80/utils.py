

def error_response(msg):
    return {
        'result': msg
    }
